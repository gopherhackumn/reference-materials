What is secret sharing?

Secret sharing is a way of securing a secret in distributed form. The secret is split into shares, such that each individual share doesnt give any information on the secret.

It's like cybersec Horcrux.

The share distribution can be designed in such a way that you may choose the number of total shares, and the number of shares required to recover the secret.

DNSSEC HSM